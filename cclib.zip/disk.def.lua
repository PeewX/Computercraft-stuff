disk = {}

function disk.isPresent() end
function disk.hasData() end
function disk.getMountPath() end
function disk.setLabel() end
function disk.getLabel() end
function disk.getID() end
function disk.hasAudio() end
function disk.getAudioTitle() end
function disk.playAudio() end
function disk.stopAudio() end
function disk.eject() end

return disk