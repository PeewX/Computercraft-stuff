os = {}

function os.version() end
function os.getComputerID() end
function os.getComputerLabel() end
function os.setComputerLabel() end
function os.run() end
function os.loadAPI() end
function os.unloadAPI() end
function os.pullEvent() end
function os.pullEventRaw() end
function os.queueEvent() end
function os.clock() end
function os.startTimer() end
function os.sleep() end
function os.time() end
function os.day() end
function os.setAlarm() end
function os.shutdown() end
function os.reboot() end

return os