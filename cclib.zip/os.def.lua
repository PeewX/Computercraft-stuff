os = {}

--- Returns the version of the OS the computer is running, which (for CraftOS) also contains the version of ComputerCraft.
---@return string
function os.version() end

--- Returns the unique ID of this computer. os.computerID() also behaves exactly the same as os.getComputerID().
---@return number
function os.getComputerID() end

--- Returns the label of this computer. os.computerLabel() also behaves exactly the same as os.getComputerLabel().
---@return string | nil
function os.getComputerLabel() end

--- Set the label of this computer.
---@param label string | nil
---@return nil
function os.setComputerLabel(label) end

--- An advanced way of starting programs.
--- A started program will have a given environment table which determines what functions it has available,
--- as well as any variables it will be able to access by default.
--- You may prefer to use the Shell (API) unless you need to do something special.
---@overload fun(environment: table, programPath: string, arguments: string): boolean
---@param environment table
---@param programPath string
---@return boolean
function os.run(environment, programPath) end

--- Loads a Lua script as an API in its own namespace. It will be available to all programs that run on the terminal.
---@param path string
---@return boolean
function os.loadAPI(path) end

--- Unloads a previously loaded API.
---@param name string
---@return nil
function os.unloadAPI(name) end

--- Blocks until the computer receives an event, or if target-event is specified, will block until an instance of target-event occurs.
--- os.pullEvent(target-event) returns the event and any parameters the event may have.
--- If a target-event is specified, the computer will not break for any other events (except termination).
---@overload fun(targetEvent: string): string, any...
---@return string, any...
function os.pullEvent() end

--- Advanced version of pullEvent().
--- Blocks until the computer receives an event, or if target-event is specified, will block until an instance of target-event occurs.
--- os.pullEventRaw(target-event) returns the event and any parameters the event may have.
--- Unlike os.pullEvent(target-event), this function will not raise an error if a 'terminate' event is received.
---@overload fun(targetEvent: string): string, any...
---@return string, any...
function os.pullEventRaw() end

--- Adds an event to the event queue with the name event and the given parameters.
---@param event string
---@param param1 any
---@vararg any
---@return nil
function os.queueEvent(event, param1, ...) end

--- Returns the amount of time since the in-game computer was started.
---@return number
function os.clock() end

--- Queues an event to be triggered after a number of seconds (timeout).
--- The ID of the timer is returned from this function to differentiate multiple timers.
--- Timers are one-shot; once they have fired an event you will need to start another one if you need a recurring timer.
---@param timeout number
---@return number
function os.startTimer(timeout) end

--- Returns the current in-game time.
---@return number
function os.time() end

--- Makes the system wait a number of seconds before continuing in the program. os.sleep(time) may also be used as simply "sleep(time)".
---@param time number
---@return nil
function os.sleep(time) end

--- Return the current in-game day (the number of in-game days since the world was created).
---@return number
function os.day() end

--- Queues an event to be triggered at the specified in-game time.
---@param time number
---@return number
function os.setAlarm(time) end

--- Turns off the computer.
---@return nil
function os.shutdown() end

--- Reboots the computer.
---@return nil
function os.reboot() end

return os