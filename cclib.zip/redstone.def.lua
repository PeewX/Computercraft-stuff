redstone = {}

--- Returns a table of possible sides.
function redstone.getSides() end

--- Returns the current redstone input signal state on side.
---@param side string
---@return boolean
function redstone.getInput(side) end

--- Sets or resets a redstone signal on side.
---@param side string
---@param value boolean
---@return nil
function redstone.setOutput(side, value) end

--- Returns the current redstone output signal on side.
---@param side string
---@return boolean
function redstone.getOutput(side) end

--- (Requires CC1.51 and above) Returns the current redstone input signal strength on side. If no input is present, returns 0. If a redstone source (such as a redstone torch or block) is directly adjacent to the computer, returns 15.
---@param side string
---@return number
function redstone.getAnalogInput(side) end

--- (Requires CC1.51 and above) Sets or resets a redstone signal on side to strength (where strength is a positive integer).
---@param side string
---@param strength number
---@return nil
function redstone.setAnalogOutput(side, strength) end

--- (Requires CC1.51 and above) Returns the current redstone output signal strength on side.
---@param side string
---@return number
function redstone.getAnalogOutput(side) end

--- Returns the state (as a number) of a bundled cable connected to side.
---@param side string
---@return number
function redstone.getBundledInput(side) end

--- Returns the set of wires in a bundled cable which are being activated by the terminal on side.
---@param side string
---@return number
function redstone.getBundledOutput(side) end

--- Returns true if color is active in a bundled cable attached to side. Else, returns false.
---@param side string
---@param colors number
---@return nil
function redstone.setBundledOutput(side, colors) end

--- Returns true if color is active in a bundled cable attached to side. Else, returns false.
---@param side string
---@param color number
---@return boolean
function redstone.testBundledInput(side, color) end

return redstone