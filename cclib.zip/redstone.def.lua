redstone = {}

function redstone.getSides() end
function redstone.getInput() end
function redstone.setOutput() end
function redstone.getOutput() end
function redstone.getBundledInput() end
function redstone.setBundledOutput() end
function redstone.getBundledOutput() end
function redstone.testBundledInput() end

return redstone