rednet = {}

--- Tells the computer that the side can be used for networking.
---@param side string
---@return nil
function rednet.open(side) end

--- Tells the computer that the side can no longer be used for networking. 
---@param side string
---@return nil
function rednet.close(side) end

--- Sends a message "intended" for another system with a specific ID, using the currently opened sides. 
--- The receiverID is the ID number (note - not a string) of the computer you're sending the message to. 
--- The types that can be sent as the message vary depending on the version of ComputerCraft in use.
---@overload fun(receiverID: number, message: any, protocol: string): boolean
---@param receiverID number
---@param message any
---@return boolean
function rednet.send(receiverID, message) end

--- Sends the message to all connected and open computers.
---@overload fun(message: any, protocol: string): nil
---@param message any
---@return nil
function rednet.broadcast(message) end

--- Waits until a rednet message of the specified protocol has been received, or until timeout seconds have passed. 
--- Leave all arguments empty to wait for any message indefinitely. 
--- If only a single, numerical argument is passed, will wait that many seconds for a message of any protocol. 
--- Versions of ComputerCraft prior to 1.6 may return the distance to the transmitting computer - 1.6 or later returns message protocols instead, 
--- though distance can still be obtained via direct use of the Modem API.
---@overload fun(timeout: number): number, any, string
---@overload fun(protocolFilter: string): number, any, string
---@overload fun(protocolFilter: string, timeout: number): number, any, string
---@return number, any, string
function rednet.receive() end

--- Returns true if the wireless modem is open. 
---@param side string
---@return boolean
function rednet.isOpen(side) end

--- Registers hostname against protocol for the purposes of rednet.lookup(). Only available in ComputerCraft 1.6 and above.
---@param protocol string
---@param hostname string
---@return nil
function rednet.host(protocol, hostname) end


--- Unregisters hostname from protocol. Only available in ComputerCraft 1.6 and above.
---@param protocol string
---@param hostname string
---@return nil
function rednet.unhost(protocol, hostname) end

--- Searches the local network for systems registered with a matching hostname and/or protocol, and returns matching IDs found. Only available in ComputerCraft 1.6 and above.
---@overload fun(protocol: string, hostname: string): number[]
---@param protocol string
---@return number[]
function rednet.lookup(protocol) end

--- Internal use function - runs automatically and does not need to be called directly. 
--- Waits for modem_message events to appear within the event queue and generates corresponding rednet_message events for use with this API. 
--- Also responds to rednet.lookup() requests. 
---@return nil
function rednet.run() end

return rednet