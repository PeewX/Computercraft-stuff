rednet = {}

function rednet.open() end
function rednet.close() end
function rednet.announce() end
function rednet.send() end
function rednet.broadcast() end
function rednet.receive() end
function rednet.isOpen() end

return rednet