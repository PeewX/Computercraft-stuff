term = {}

function term.write() end
function term.clear() end
function term.clearLine() end
function term.getCursorPos() end
function term.setCursorPos() end
function term.setCursorBlink() end
function term.isColor() end
function term.scroll() end
function term.restore() end
function term.setTextColor() end
function term.setBackgroundColor() end

return term