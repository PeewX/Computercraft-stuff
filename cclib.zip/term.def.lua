term = {}

--- Writes text to the screen, using the current text and background colors.
---@param text string
---@return nil
function term.write(text) end

--- Writes text to the screen using the specified text and background colors.
--- Requires version 1.74 or newer.
---@param text string
---@param textColors string
---@param backgroundColors string
---@return nil
function term.blit(text, textColors, backgroundColors) end

--- Clears the entire screen.
---@return nil
function term.clear() end

--- Clears the line the cursor is on.
---@return nil
function term.clearLine() end

--- Returns two arguments containing the x and the y position of the cursor.
---@return number, number x, y
function term.getCursorPos() end

--- Sets the cursor's position.
---@return nil
function term.setCursorPos(x, y) end

--- Disables the blinking or turns it on.
---@return nil
function term.setCursorBlink(bool) end

--- Returns whether the terminal supports color.
---@return boolean
function term.isColor() end

--- Returns two arguments containing the x and the y values stating the size of the screen.
--- (Good for if you're making something to be compatible with both Turtles and Computers.)
---@return number, number x, y
function term.getSize() end

--- Scrolls the terminal n lines.
---@param n number
---@return nil
function term.scroll(n) end

--- Redirects terminal output to another terminal object (such as a window or wrapped monitor).
--- Available only to the base term object.
---@param target table
---@return table previous terminal Object
function term.redirect(target) end

--- Returns the current terminal object.
--- Requires version 1.6 or newer, available only to the base term object.
---@return table terminal Object
function term.current() end

--- Returns the original terminal object.
--- Requires version 1.6 or newer, available only to the base term object.
---@return table terminal Object
function term.native() end

--- Sets the text color of the terminal.
--- Limited functionality without an Advanced Computer / Turtle / Monitor.
---@return nil
function term.setTextColor(color) end

--- Returns the current text color of the terminal.
--- Requires version 1.74 or newer.
---@return number color
function term.getTextColor() end

--- Sets the background color of the terminal.
--- Limited functionality without an Advanced Computer / Turtle / Monitor.
---@return nil
function term.setBackgroundColor(color) end

--- Returns the current background color of the terminal.
--- Requires version 1.74 or newer.
---@return number color
function term.getBackgroundColor() end

return term