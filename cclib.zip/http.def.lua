http = {}

function http.request() end
function http.get() end
function http.post() end

return http