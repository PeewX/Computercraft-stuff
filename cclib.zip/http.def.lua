http = {}

--- Sends a HTTP request to a website, asynchronously.
---@overload fun(url: string, postData: string): nil
---@overload fun(url: string, postData: string, headers: table): nil
---@param url string
---@return nil
function http.request(url) end

--- Sends a HTTP GET request to a website, synchronously.
---@overload fun(url: string, headers: table): table | nil
---@param url string
---@return table | nil
function http.get(url) end

--- Sends a HTTP POST request to a website, synchronously.
---@overload fun(url: string, postData: string, headers: table): table | nil
---@param url string
---@param postData string
---@return table | nil
function http.post(url, postData) end

--- Checks if a URL is valid and is included in the HTTP whitelist.
---@param url string
---@return boolean, string
function http.checkURL(url) end

return http