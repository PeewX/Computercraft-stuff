keys = {}

--- Translates a numerical key code to a human-readable name.
---@param code number
---@return string
function keys.getName(code) end

return keys