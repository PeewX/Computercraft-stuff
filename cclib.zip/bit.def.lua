bit = {}

--- Shifts a number left by a specified number of bits.
---@param n number
---@param bits number
---@return number
function bit.blshift(n, bits) end

--- Shifts a number right arithmetically by a specified number of bits.
---@param n number
---@param bits number
---@return number
function bit.brshift(n, bits) end

--- Shifts a number right logically by a specified number of bits.
---@param n number
---@param bits number
---@return number
function bit.blogic_rshift(n, bits) end

--- Computes the bitwise exclusive OR of two numbers.
---@param m number
---@param n number
---@return number
function bit.bxor(m, n) end

--- Computes the bitwise inclusive OR of two numbers.
---@param m number
---@param n number
---@return number
function bit.bor(m, n) end

--- Computes the bitwise AND of two numbers.
---@param m number
---@param n number
---@return number
function bit.band(m, n) end

--- Computes the bitwise NOT of a number.
---@param n number
---@return number
function bit.boot(n) end

return bit