bit = {}

function bit.blshift() end
function bit.brshift() end
function bit.blogic_rshift() end
function bit.bxor() end
function bit.bor() end
function bit.annd() end
function bit.noot() end

return bit