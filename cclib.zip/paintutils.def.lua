paintutils = {}

--- Loads and returns an image object from path.
---@param path string
---@return table | nil
function paintutils.loadImage(path) end

--- Draws an image at (x, y) where image is an image object.
---@param image table
---@param x number
---@param y number
---@return nil
function paintutils.drawImage(image, x, y) end

--- Draws a pixel at (x, y) in the specified color.
---@overload fun(x: number, y: number, color: number): nil
---@param x number
---@param y number
---@return nil
function paintutils.drawPixel(x, y) end

--- Draws a line from (startX, startY) to (endX, endY) in the specified color.
---@overload fun(startX: number, startY: number, endX: number, endY: number, color: number): nil
---@param startX number
---@param startY number
---@param endX number
---@param endY number
---@return nil
function paintutils.drawLine(startX, startY, endX, endY) end

--- Draws a box from (startX, startY) to (endX, endY) in the specified color. Requires version 1.64 or newer.
---@overload fun(startX: number, startY: number, endX: number, endY: number, color: number): nil
---@param startX number
---@param startY number
---@param endX number
---@param endY number
---@return nil
function paintutils.drawBox(startX, startY, endX, endY) end

--- Draws a filled box from (startX, startY) to (endX, endY) in the specified color. Requires version 1.64 or newer.
---@overload fun(startX: number, startY: number, endX: number, endY: number, color: number): nil
---@param startX number
---@param startY number
---@param endX number
---@param endY number
---@return nil
function paintutils.drawFilledBox(startX, startY, endX, endY) end

return paintutils