paintutils = {}
function paintutils.loadImage() end
function paintutils.drawImage() end
function paintutils.drawPixel() end
function paintutils.drawLine() end

return paintutils