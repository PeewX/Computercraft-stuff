peripheral = {}

function peripheral.isPresent() end
function peripheral.getType() end
function peripheral.getMethods() end
function peripheral.call() end
function peripheral.wrap() end

return peripheral