colors = {}

--- Combines one or more colors (or sets of colors) into a larger set.
---@param color1 number
---@param color2 number
---@vararg number
---@return number
function colors.combine(color1, color2, ...) end

--- Removes one or more colors (or sets of colors) from an initial set;
--- each parameter beyond the first may be a single color or may be a set of colors (in the latter case, all colors in the set are removed from the original set).
---@param colors number
---@param color1 number
---@param color2 number
---@vararg number
---@return number
function colors.subtract(colors, color1, color2, ...) end

--- Tests whether color is contained within colors;
--- color may be a single color or may be a set of colors (in the latter case, true is returned only if all colors in color are contained in colors)
---@param colors number
---@param color number
---@return boolean
function colors.test(colors, color) end

return colors