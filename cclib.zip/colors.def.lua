colors = {}

function colors.combine() end
function colors.subtract() end
function colors.test() end

return colors