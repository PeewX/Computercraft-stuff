vector = {}

--- Creates a vector.
---@param x number
---@param y number
---@param z number
function vector.new(x, y, z) end

--- Adds vectorB to vectorA and returns the resulting vector. Can also be used by writing vectorA + vectorB.
function vector:add(vectorB) end

--- Subtracts vectorB from vectorA and returns the resulting vector. Can also be used by writing vectorA - vectorB.
function vector:sub(vectorB) end

--- Scalar multiplies vectorA with n and returns the resulting vector. Can also be used by writing vectorA * n.
---@param n number
function vector:mul(n) end

--- Returns the dot product of vectorA and vectorB.
function vector:dot(vector) end

--- Returns the vector which resulted in the cross product of vectorA and vectorB.
function vector:cross(vector) end

--- Returns the vector's length.
---@return number length
function vector:length() end

--- Normalizes the vector and returns the result as a new vector.
function vector:normalize() end

--- Rounds the vector coordinates to the nearest integers and returns the result as a new vector.
function vector:round() end

--- Returns a string representation of the vector in the form of "x,y,z".
---@return string "x,y,z"
function vector:tostring() end

return vector