vector = {}

function vector.new() end
function vector.x() end
function vector.y() end
function vector.z() end
function vector:add() end
function vector:sub() end
function vector:mul() end
function vector:dot() end
function vector:cross() end
function vector:length() end
function vector:normalize() end
function vector:round() end
function vector:tostring() end

return vector