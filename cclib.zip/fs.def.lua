fs = {}

--- Returns a list of all the files (including subdirectories but not their contents) contained in a directory, as a numerically indexed table.
---@param path string
---@return table
function fs.list(path) end

--- Checks if a path refers to an existing file or directory.
---@param path string
---@return boolean
function fs.exists(path) end

--- Checks if a path refers to an existing directory.
---@param path string
---@return boolean
function fs.isDir(path) end

--- Checks if a path is read-only (i.e., cannot be modified).
---@param path string
---@return boolean
function fs.isReadOnly(path) end

--- Gets the final component of a pathname.
---@param path string
---@return string
function fs.getName(path) end

--- Gets the storage medium holding a path, or nil if the path does not exist.
---@param path string
---@return string | nil
function fs.getDrive(path) end

--- Gets the size of a file in bytes.
---@param path string
---@return number
function fs.getSize(path) end

--- Gets the remaining space on the drive containing the given directory.
---@param path string
---@return number
function fs.getFreeSpace(path) end

--- Makes a directory.
---@param path string
---@return nil
function fs.makeDir(path) end

--- Moves a file or directory to a new location.
---@param from string
---@param to string
---@return nil
function fs.move(from, to) end

--- Copies a file or directory to a new location.
---@param from string
---@param to string
---@return nil
function fs.copy(from, to) end

--- Deletes a file or directory.
---@param path string
---@return nil
function fs.delete(path) end

--- Combines two path components, returning a path consisting of the local path nested inside the base path.
---@param basePath string
---@param localPath string
---@return string
function fs.combine(basePath, localPath) end

--- Opens a file so it can be read or written.
---@param path string
---@param mode string
---@return table
function fs.open(path, mode) end

--- Searches the computer's files using wildcards. Requires version 1.6 or later.
---@param pattern string
---@return table
function fs.find(pattern) end

--- Returns the parent directory of path. Requires version 1.63 or later.
---@param path string
---@return string
function fs.getDir(path) end

--- Returns a list of strings that could be combined with the provided name to produce valid entries in the specified folder. Requires version 1.74 or later.
---@overload fun(file: string, path: string, includeFiles: boolean): table
---@overload fun(file: string, path: string, includeFiles: boolean, includeSlashes: boolean): table
---@param file string
---@param path string
---@return table
function fs.complete(file, path) end

return fs