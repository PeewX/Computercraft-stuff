fs = {}

function fs.list() end
function fs.exists() end
function fs.isDir() end
function fs.isReadOnly() end
function fs.getName() end
function fs.getDrive() end
function fs.getSize() end
function fs.getFreeSpace() end
function fs.makeDir() end
function fs.move() end
function fs.copy() end
function fs.delete() end
function fs.combine() end
function fs.open() end

return fs