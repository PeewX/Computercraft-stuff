turtle = {}

--- Craft items using ingredients anywhere in the turtle's inventory and place results in the active slot.
--- If a quantity is specified, it will craft only up to that many items, otherwise, it will craft as many of the items as possible.
---@param quantity number
---@return boolean
function turtle.craft(quantity) end

--- Try to move the turtle forward
---@return boolean
function turtle.forward() end

--- Try to move the turtle backwards
---@return boolean
function turtle.back() end

--- Try to move the turtle up
---@return boolean
function turtle.up() end

--- Try to move the turtle down
---@return boolean
function turtle.down() end

--- Turn the turtle left
---@return boolean
function turtle.turnLeft() end

--- Turn the turtle right
---@return boolean
function turtle.turnRight() end

--- Make the turtle select slot slotNum (1 is top left, 16 (9 in 1.33 and earlier) is bottom right)
---@param slotNum number
---@return boolean
function turtle.select(slotNum) end

--- Indicates the currently selected inventory slot
---@return number
function turtle.getSelectedSlot() end

--- Counts how many items are in the currently selected slot or, if specified, slotNum slot
---@overload fun(slotNum: number): number
---@return number
function turtle.getItemCount() end

--- Counts how many remaining items you need to fill the stack in the currently selected slot or, if specified, slotNum slot
---@overload fun(slotNum: number): number
---@return number
function turtle.getItemSpace() end

--- Returns the ID string, count and damage values of currently selected slot or, if specified, slotNum slot
---@overload fun(slotNum: number): table
---@return table
function turtle.getItemDetail() end

--- Attacks in front of the turtle.
---@overload fun(toolSide: string): boolean
---@return boolean
function turtle.attack() end

--- Attacks above the turtle.
---@overload fun(toolSide: string): boolean
---@return boolean
function turtle.attackUp() end

--- Attacks under the turtle.
---@overload fun(toolSide: string): boolean
---@return boolean
function turtle.attackDown() end

--- Breaks the block in front. With hoe: tills the dirt in front of it.
---@overload fun(toolSide: string): boolean
---@return boolean
function turtle.dig() end

--- Breaks the block above.
---@overload fun(toolSide: string): boolean
---@return boolean
function turtle.digUp() end

--- Breaks the block below. With hoe: tills the dirt beneath the space below it.
---@overload fun(toolSide: string): boolean
---@return boolean
function turtle.digDown() end

--- Places a block of the selected slot in front. Engrave signText on signs if provided.
--- Collects water or lava if the currently selected slot is an empty bucket.
---@overload fun(signText: string): boolean
---@return boolean
function turtle.place() end

--- Places a block of the selected slot above. Collects water or lava if the currently selected slot is an empty bucket.
---@return boolean
function turtle.placeUp() end

--- Places a block of the selected slot below. Collects water or lava if the currently selected slot is an empty bucket.
---@return boolean
function turtle.placeDown() end

--- Detects if there is a block in front. Does not detect mobs.
---@return boolean
function turtle.detect() end

--- Detects if there is a block above.
---@return boolean
function turtle.detectUp() end

--- Detects if there is a block below.
---@return boolean
function turtle.detectDown() end

--- Returns the ID string and metadata of the block in front of the Turtle.
---@return boolean, table | string
function turtle.inspect() end

--- Returns the ID string and metadata of the block above the Turtle.
---@return boolean, table | string
function turtle.inspectUp() end

--- Returns the ID string and metadata of the block below the Turtle.
---@return boolean, table | string
function turtle.inspectDown() end

--- Detects if the block in front is the same as the one in the currently selected slot.
---@return boolean
function turtle.compare() end

--- Detects if the block above is the same as the one in the currently selected slot.
---@return boolean
function turtle.compareUp() end

--- Detects if the block below is the same as the one in the currently selected slot.
---@return boolean
function turtle.compareDown() end

--- Compare the current selected slot and the given slot to see if the items are the same.
--- Returns true if they are the same, false if not.
---@param slot number
---@return boolean
function turtle.compareTo(slot) end

--- Drops all items in the selected slot, or specified, drops count items.
--- [>= 1.4 only:] If there is a inventory on the side (i.e in front of the turtle) it will try to place into the inventory, returning false if the inventory is full.
---@overload fun(count: number): boolean
---@return boolean
function turtle.drop() end

--- Drops all items in the selected slot, or specified, drops count items.
--- [>= 1.4 only:] If there is a inventory on the side (i.e above the turtle) it will try to place into the inventory, returning false if the inventory is full.
---@overload fun(count: number): boolean
---@return boolean
function turtle.dropUp() end

--- Drops all items in the selected slot, or specified, drops count items.
--- [>= 1.4 only:] If there is a inventory on the side (i.e below the turtle) it will try to place into the inventory, returning false if the inventory is full.
--- If above a furnace, will place item in the top slot.
---@overload fun(count: number): boolean
---@return boolean
function turtle.dropDown() end

--- Picks up an item stack of any number, from the ground or an inventory in front of the turtle, then places it in the selected slot.
--- If the turtle can't pick up the item, the function returns false. amount parameter requires ComputerCraft 1.6 or later.
---@overload fun(amount: number): boolean
---@return boolean
function turtle.suck() end

--- Picks up an item stack of any number, from the ground or an inventory above the turtle, then places it in the selected slot.
--- If the turtle can't pick up the item, the function returns false. amount parameter requires ComputerCraft 1.6 or later.
---@overload fun(amount: number): boolean
---@return boolean
function turtle.suckUp() end

--- Picks up an item stack of any number, from the ground or an inventory below the turtle, then places it in the selected slot.
--- If the turtle can't pick up the item, the function returns false. amount parameter requires ComputerCraft 1.6 or later.
---@overload fun(amount: number): boolean
---@return boolean
function turtle.suckDown() end

--- If the current selected slot contains a fuel item, it will consume it to give the turtle the ability to move.
--- Added in 1.4 and is only needed in need fuel mode.
--- If the current slot doesn't contain a fuel item, it returns false.
--- Fuel values for different items can be found at Turtle.refuel#Fuel_Values.
--- If a quantity is specified, it will refuel only up to that many items, otherwise, it will consume all the items in the slot.
---@overload fun(quantity: number): boolean
---@return boolean
function turtle.refuel() end

--- Returns the current fuel level of the turtle, this is the number of blocks the turtle can move.
--- If turtleNeedFuel = 0 then it returns "unlimited".
---@return number
function turtle.getFuelLevel() end

--- Returns the maximum amount of fuel a turtle can store - by default, 20,000 for regular turtles, 100,000 for advanced.
--- If turtleNeedFuel = 0 then it returns "unlimited".
---@return number
function turtle.getFuelLimit() end

--- Transfers quantity items from the selected slot to slot.
--- If quantity isn't specified, will attempt to transfer everything in the selected slot to slot.
---@overload fun(slot: number, quantity: number): boolean
---@param slot number
---@return boolean
function turtle.transferTo(slot) end

return turtle