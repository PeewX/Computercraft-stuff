commands = {}

--- Executes the specified command, yields until the result is determined, then returns it.
---@param command string
---@return boolean, table success, output
function commands.exec(command) end

--- Executes the specified command, but doesn't yield.
--- Queues a "task_complete" event after the command is executed.
---@param command string
---@return number taskID
function commands.execAsync(command) end

--- Returns a numerically indexed table filled with strings representing acceptable commands for commands.exec() / commands.execAsync().
---@return table commands
function commands.list() end

--- Returns the Minecraft world coordinates of the computer running the command.
---@return number, number, number x, y, z
function commands.getBlockPosition() end

--- Returns a table containing info about the block at the specified world location.
--- Keys are "name" (a string) and "metadata" (a number).
---@param x number
---@param y number
---@param z number
---@return table block info
function commands.getBlockInfo(x, y, z) end

--- Returns a table containing sub-tables with info about the blocks within the specified world locations.
--- Added by CC 1.76
---@param x1 number
---@param y1 number
---@param z1 number
---@param x2 number
---@param y2 number
---@param z2 number
---@return table blocks info
function commands.getBlockInfos(x1, y1, z1, x2, y2, z2) end

return commands