shell = {}

function shell.exit() end
function shell.dir() end
function shell.setDir() end
function shell.path() end
function shell.setPath() end
function shell.resolve() end
function shell.resolveProgram() end
function shell.aliases() end
function shell.setAliases() end
function shell.clearAliases() end
function shell.programs() end
function shell.run() end
function shell.getRunningProgram() end

return shell