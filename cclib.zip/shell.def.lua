shell = {}

--- Exits the current shell.
---@return nil
function shell.exit() end

--- Returns the path to the working directory.
---@return string directory
function shell.dir() end

--- Sets the working directory.
---@param path string
---@return nil
function shell.setDir(path) end

--- Returns the path to the working directory.
---@return string path
function shell.path() end

--- Sets the path.
---@param path string
---@return nil
function shell.setPath(path) end

--- Returns the path.
---@param localPath string
---@return string absolutePath
function shell.resolve(localPath) end

--- Resolves a local path to an absolute path.
---@param name string
---@return string absolutePath
function shell.resolveProgram(name) end

--- Returns aliases.
---@return table aliases
function shell.aliases() end

--- Sets an alias for a program.
---@param alias string
---@param program string
---@return nil
function shell.setAlias(alias, program) end

--- Clears an alias.
---@param alias string
---@return nil
function shell.clearAlias(alias) end

--- Returns a table of files in the current directory and in all paths in shell.path.
---@overload fun(showHidden: boolean): table
---@return table programs
function shell.programs() end

--- Returns the absolute path to the currently-executing program.
---@return string path
function shell.getRunningProgram() end

--- Runs a command (program).
---@overload fun(command: string, args: string...): number
---@param command string
---@return boolean success
function shell.run(command) end

--- Runs a program in another multishell tab. Requires version 1.6 or newer and an advanced system.
---@overload fun(command: string, args: string...): number
---@param command string
---@return number tabID
function shell.openTab(command) end

--- Switches the multishell tab to the tab with the given ID. Requires version 1.6 or newer and an advanced system.
---@param tabID number
---@return nil
function shell.switchTab(tabID) end

--- Given a partial command line, returns a list of suffixes that could potentially be used to complete it. Requires version 1.74 or newer.
---@param prefix string
---@return table completionList
function shell.complete(prefix) end

--- Given a partial script/directory path, returns a list of suffixes that could potentially be used to complete it, including alias and path matches. Requires version 1.74 or newer.
---@param prefix string
---@return table completionList
function shell.completeProgram(prefix) end

--- Registers a function that determines how shell.complete() handles completion behavior for a given script. Requires version 1.74 or newer.
---@param path string
---@param completionFunction function
---@return nil
function shell.setCompletionFunction(path, completionFunction) end

--- Returns a pointer to the table containing functions registered by shell.setCompletionFunction() for use with shell.complete(). Requires version 1.74 or newer.
---@return table completionFunctions
function shell.getCompletionInfo() end

return shell