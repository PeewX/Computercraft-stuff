settings = {}

--- Sets the setting name to value. Sets the setting name to value.
---@param name string
---@param value any
---@return nil
function settings.set(name, value) end

--- Returns the setting's name value, or default if the setting does not exist.
---@overload fun(name: string, default: any): nil
---@param name string
---@return any value
function settings.get(name) end

--- Removes the setting name.
---@param name string
---@return nil
function settings.unset(name) end

--- Removes all settings.
---@return nil
function settings.clear() end

--- Returns a numerically-indexed table of all the setting's names.
---@return table settingNames
function settings.getNames() end

--- Loads settings from a file.
---@param path string
---@return boolean loaded
function settings.load(path) end

--- Saves current settings to a file.
---@param path string
---@return boolean saved
function settings.save(path) end

return settings