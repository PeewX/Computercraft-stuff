monitor = {}

--- Sets the text scale. Available only to monitor objects.
---@param scale number
---@return nil
function monitor.setTextScale(scale) end

return monitor