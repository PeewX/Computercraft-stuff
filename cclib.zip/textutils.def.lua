textutuls = {}

function textutuls.slowPrint() end
function textutuls.slotWrite() end
function textutuls.formatTime() end
function textutuls.tabulate() end
function textutuls.pagedTabulate() end
function textutuls.pagedPrint() end
function textutuls.serialize() end
function textutuls.unserialize() end
function textutuls.urlEncode() end

return textutuls