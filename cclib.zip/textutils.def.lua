textutils = {}

--- Writes string text at current cursor position, character-by-character.
--- Number argument rate is optional and is defaulted to 20.
--- The higher the value of rate, the faster text is written
--- (passing a value of 1 writes one character per second).
---@param text string
---@param rate number
---@return nil
function textutils.slowWrite(text, rate) end

--- Writes string 'text' at the current cursor position, character-by-character.
--- Number argument 'rate' is optional and is defaulted to 20.
--- The higher the value of 'rate', the faster 'text' is written.
--- (Passing a value of 1 writes one character per second).
---@param text string
---@param rate number
---@return nil
function textutils.slowPrint(text, rate) end

--- Takes input 'time' and formats it in a more readable format.
--- If the second value 'twentyFourHour' is true, returns time in twenty-four-hour format;
--- if the second value is false, returns time in twelve-hour format, with AM or PM.
--- Default for 'twentyFourHour' is false.
---@param time number
---@param twentyFourHour boolean
---@return string formattedTime
function textutils.formatTime(time, twentyFourHour) end

--- Prints tables in an ordered form.
--- Each table is a row, the column width is auto-adjusted.
--- If it encounters a number instead of a table then sets the text color to it.
---@vararg table|number
---@return nil
function textutils.tabulate(...) end

--- Prints tables in an ordered form, waits for confirmation before scrolling down.
---@vararg table|number
---@return nil
function textutils.pagedTabulate(...) end

--- Prints string 'text' onto the screen, but waits for confirmation
--- (after at least 'freeLines' have been scrolled) before scrolling down further.
--- Default for 'freeLines' is 0.
---@overload fun(text: string, freeLines: number): number
---@param text string
---@return number linesPrinted
function textutils.pagedPrint(text, freeLines) end

--- Returns a string representation of the data 'data' for storage or transmission.
--- Also exists as textutils.serializes under CC 1.6 or later.
---@param data table|string|number|boolean|nil
---@return string serializedData
function textutils.serialize(data) end

--- Returns the data reassembled from string 'serializedData'.
--- Used mainly together with textutils.serialize().
--- Also exists as textutils.unserializes under CC 1.6 or later.
---@param serializedData string
---@return any unserializedData
function textutils.unserialize(serializedData) end

--- Returns a JSON representation of the data 'data' in the form of a string.
--- Mainly for command usage. Also exists as textutils.serializeJSON.
--- Requires CC 1.7 or later.
---@overload fun(data: table|string|number|boolean, unquoteKeys: boolean): string
---@param data table|string|number|boolean
---@return string serializedData
function textutils.serializeJSON(data) end

--- Makes a string safe to encode into a URL.
--- Spaces are replaced with '+'s.
--- Unsafe characters such as '\', '£' and '}' are translated into ASCII code
--- and preceded with a % for transmission.
---@param urlUnsafeString string
---@return string urlSafeString
function textutils.urlEncode(urlUnsafeString) end

--- Returns a list of strings that could be combined with the provided name
--- to produce valid entries in the specified environment.
--- Requires version 1.74 or later.
---@overload fun(partialName: string, environment: table): table
---@param partialName string
---@return table matches
function textutils.complete(partialName) end

return textutils