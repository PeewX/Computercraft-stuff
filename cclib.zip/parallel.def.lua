parallel = {}

function parallel.waitForAny() end
function parallel.waitForAll() end

return parallel