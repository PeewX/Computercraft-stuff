parallel = {}

--- Runs all the functions at the same time, and stops when any of them returns.
---@param function1 function
---@param function2 function
---@vararg function
---@return number
function parallel.waitForAny(function1, function2, ...) end

--- Runs all the functions at the same time, and stops when all of them have returned.
---@param function1 function
---@param function2 function
---@vararg function
---@return nil
function parallel.waitForAll(function1, function2, ...) end

return parallel