window = {}

--- Creates and returns a new window object, similar to a wrapped monitor.
--- Refer to the term API for a list of functions attached to it.
---@overload fun(parentTerm: table, x: number, y: number, width: number, height: number): table
---@param parentTerm table
---@param x number
---@param y number
---@param width number
---@param height number
---@return table windowObject
function window.create(parentTerm, x, y, width, height) end

--- Determines whether subsequent renders to the window will be visible.
--- Available only to window objects.
---@param visibility boolean
---@return nil
function window.setVisible(visibility) end

--- Redraws the contents of the window.
--- Available only to window objects.
---@return nil
function window.redraw() end

--- Returns the cursor back to its position / state within the window.
--- Available only to window objects.
---@return nil
function window.restoreCursor() end

--- Returns the top left co-ordinate of the window.
--- Available only to window objects.
---@return number, number x, y
function window.getPosition() end

--- Moves and / or resizes the window.
--- Available only to window objects.
---@overload fun(x: number, y: number, width: number, height: number): nil
---@param x number
---@param y number
---@return nil
function window.reposition(x, y) end

return window