gps = {}

function gps.locate() end

return gps