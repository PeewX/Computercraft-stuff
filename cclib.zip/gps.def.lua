gps = {}

--- Tries to retrieve the computer or turtles own location.
--- On success, returns the location of the turtle’s modem.
--- On failure (if no responses are received for timeout seconds, by default 2), returns nil.
--- If debug is true, debug messages are printed.
---@overload fun(timeout: number): (number, number, number) | nil
---@overload fun(timeout: number, debug: boolean): (number, number, number) | nil
---@return (number, number, number) | nil
function gps.locate() end

return gps